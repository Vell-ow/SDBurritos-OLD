package sample;

// Car wash cash register

// Wallet class - Double
// Only one type of waller - $5.99

// AirFreshener Class - String, Double
// AirFreshener 1 - Free $0.00
// AirFreshener 2 - Tree $1.79
// AirFreshener 3 - Canister $3.99
// AirFreshener 4 - Vent Clip $4.99

// Refund function, remove a select item from the cash register's saved arraylist and subtract the double value of that item from the list

// Tip accounting function - if the customer wants to leave a tip, add the tip total to the arraylist
// Tip Class - Double

// Taxable class - apply tax to untaxed values

// Receipt class - structured string of all values stored in the arraylist

// Admin class - Perform admin functions

// Void button - Remove an item from the arraylist

// Change function

// .01, .05, .10, .25, .50, 1, 2, 5, 10, 20, 50, 100 constants

// Credit/Debit buttons to take input which has CashBack as a subclass

// CashBack subclass and function

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import model.AirFreshener;
import model.Wallet;
import model.Wash;

import java.io.*;
import java.util.ArrayList;
/*
public class Main extends Application
{
*/


    /*
    public static boolean binaryFileHasData()
    {

        // TODO: Create a File reference to the binary file
        File burritoRef = new File("BINARY_FILE.dat");
        // TODO: Return whether the binary file exists and has data
        return burritoRef.exists() && burritoRef.length() > 0;

    }
    */
/*
    AirFreshener daf = new AirFreshener("Default", 1.00, "Lemony Fresh", 1, 2);
    Wallet dw = new Wallet("Default Wallet", 1.00, "Leather", 2);
        ObjectOutputStream a;
        ObjectOutputStream b;

    {

            */
        /*
        if(binaryFileHasData())
        {
            // TODO: Instantiate an ObjectInputStream reference to the binary file for reading
            try {
                ObjectInputStream fileReader = new ObjectInputStream(new FileInputStream("BINARY_FILE.dat"));
                Extras[] tempArray = (Extras[]) fileReader.readObject();
                .addAll(tempArray);
                fileReader.close();
            } catch (IOException | ClassNotFoundException e) {
                System.err.println("Error reading: " + e.getMessage());
            }
        try {
            a = new ObjectOutputStream(new FileOutputStream("AirFresheners.dat"));
            b = new ObjectOutputStream(new FileOutputStream("Wallets.dat"));
            a.writeObject(daf);
            b.writeObject(dw);

            a.close();
            b.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

         */
            /*
    }



    {
        try {
            a = new ObjectOutputStream(new FileOutputStream("AirFresheners.dat"));
            a.writeObject(daf);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // declare fields for every component that the user interacts with/changes
    ArrayList<Double> washes = new ArrayList<>();
    /*
    double min = 0.00;
    double max = 500.00;
    double defaultValue = 13.99;
     */
/*
    static Button[][] buttonsArray = new Button[6][10];


    public static void main(String[] args) {

        ArrayList<Wash> washArrayList = new ArrayList<Wash>();

        // TODO: implement changeable binary file using burrito .dat template

        buttonsArray[2][4] = new Button("CAR WASH");
        buttonsArray[2][5] = new Button("EXTRAS");

        buttonsArray[2][4].setOnAction(new EventHandler<ActionEvent>()
        {
            @Override
            public void handle(ActionEvent e)
            {
                washArrayList.add(new Wash("Basic Wash", 10.00));
                // TODO: Add a car wash of the specified type to the Node named "Basic Wash" with its price set to $10.00 so something like new Wash("Basic Wash", 10.00); and use %.2f
                /*
                int extrasType = 0;
                extrasType = JOptionPane.showOptionDialog(null, "What are you adding to the car wash?", "Add Extras", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, buttons, buttons[0]);
                */
                // TODO: Open a new dialogue in which the user is given the option to either add more items or pay
                // TODO: if the user selects "add more items"(in this case, 0), close the window and take them back to the original scene
                // TODO: if the user selects "pay"(in this case, 0), System.out.println(Wash.toString());
/*
}
        });
        */

        /*
        buttonsArray[0][0] = new Button("RECT FEED");
        buttonsArray[0][1] = new Button("DETL FEED");
        buttonsArray[0][2] = new Button("RCPT ON/OFF");
        buttonsArray[0][3] = new Button("NO SALE/UNLOCK\n\t DRAWER");
        buttonsArray[0][4] = new Button("TAX1 SHIFT");
        buttonsArray[0][5] = new Button("TAX2 SHIFT");
        buttonsArray[0][6] = new Button("FS SHIFT");
        buttonsArray[0][7] = new Button("RECD ACCT");
        buttonsArray[0][8] = new Button("PAID OUT");
        buttonsArray[0][9] = new Button("CLERK");
        buttonsArray[1][0] = new Button("MACRO 1");
        buttonsArray[1][1] = new Button("MACRO 2");
        buttonsArray[1][2] = new Button("MACRO 3");
        buttonsArray[1][3] = new Button("MACRO 4");
        buttonsArray[1][4] = new Button("MACRO 5");
        buttonsArray[1][5] = new Button(".");
        buttonsArray[1][6] = new Button("FULL SERVICE WASH");
        buttonsArray[1][7] = new Button("FREE WASH");
        buttonsArray[1][8] = new Button("MANAGERS SPECIAL");
        buttonsArray[1][9] = new Button("CASH");
        buttonsArray[2][0] = new Button("ERROR CORR");
        buttonsArray[2][1] = new Button("PLU");
        buttonsArray[2][2] = new Button("CLEAR");
        buttonsArray[2][3] = new Button("X/TIME");
        buttonsArray[2][4] = new Button("GOLD WASH");
        buttonsArray[2][5] = new Button("SPRAY WAX KEY");
        buttonsArray[2][6] = new Button("THE WORKS");
        buttonsArray[2][7] = new Button("CHARGE 2");
        buttonsArray[2][8] = new Button("VOID");
        buttonsArray[2][9] = new Button(" ");
        buttonsArray[3][0] = new Button("7");
        buttonsArray[3][1] = new Button("8");
        buttonsArray[3][2] = new Button("9");
        buttonsArray[3][3] = new Button("OPEN COUPON");
        buttonsArray[3][4] = new Button("AIR FRESHENER");
        buttonsArray[3][5] = new Button("EXTRA");
        buttonsArray[3][6] = new Button("FS TEND");
        buttonsArray[3][7] = new Button("CHARGE 1");
        buttonsArray[3][8] = new Button("CANCEL");
        buttonsArray[3][9] = new Button("RETURN ");
        buttonsArray[4][0] = new Button("4");
        buttonsArray[4][1] = new Button("5");
        buttonsArray[4][2] = new Button("6");
        buttonsArray[4][3] = new Button("SUPER WASH");
        buttonsArray[4][4] = new Button("GOLD WASH \n\t COUPON");
        buttonsArray[4][5] = new Button("DETAIL");
        buttonsArray[4][6] = new Button("CHEQUE");
        buttonsArray[4][7] = new Button("ITEM DISC");
        buttonsArray[4][8] = new Button("%3");
        buttonsArray[4][9] = new Button("1");
        buttonsArray[5][0] = new Button("2");
        buttonsArray[5][1] = new Button("3");
        buttonsArray[5][2] = new Button("DELUXE WASH");
        buttonsArray[5][3] = new Button("COUPON SUPER \n\tWASH");
        buttonsArray[5][4] = new Button("SANTA FE SPECIAL");
        buttonsArray[5][5] = new Button("SUBTOTAL");
        buttonsArray[5][6] = new Button("COUP");
        buttonsArray[5][7] = new Button("%4");
        buttonsArray[5][8] = new Button("0");
        buttonsArray[5][9] = new Button("00");

        for(Method x : javafx.scene.control.Button.class.getMethods())
        {
            System.out.println(x);
        }
        */
        /*
        Application.launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception
    {

        GridPane gp = new GridPane();

        // Set the margins (gap) to 5 pixels horizontally
        // and vertically
        gp.setHgap(5);
        gp.setVgap(5);
        gp.setAlignment(Pos.TOP_LEFT);
        */

        /*
        for(int col = 0; col < 10; col++)
        {
            for(int row = 0; row < 6; row++)
            {
                buttonsArray[row][col].setMinWidth(125);
                buttonsArray[row][col].setMaxWidth(125);
                buttonsArray[row][col].setMinHeight(100);
                buttonsArray[row][col].setMaxHeight(100);
                gp.add(buttonsArray[row][col], col + 1 * 5, row + 1 * 5);

            }
        }
        */
/*
        gp.add(buttonsArray[2][4], 4, 2);
        gp.add(buttonsArray[2][5], 5, 2);
*/
        /*
        gp.add(rectf, 5, 5);
        gp.add(detlf, 10, 5);
        gp.add(rcptOnOff, 15, 5);
        gp.add(nosale, 20, 5);
        gp.add(tax1, 25, 5);
        gp.add(tax2, 30, 5);
        gp.add(fsshift, 35, 5);
        gp.add(recd, 40, 5);
        gp.add(paid, 45, 5);
        gp.add(clerk, 50, 5);
        gp.add(macro1, 0, 9);
        gp.add(macro2, 5, 9);
        gp.add(macro3, 10, 9);
        gp.add(macro4, 15, 9);
        gp.add(macro5, 20, 9);
        gp.add(decimal, 25, 9);
        gp.add(full, 30, 9);
        gp.add(free, 35, 9);
        gp.add(mgr, 40, 9);
        gp.add(cash, 45, 9);
        gp.add(error, 0, 14);
        gp.add(plu, 5, 14);
        gp.add(clr, 10, 14);
        gp.add(xtime, 15, 14);
        gp.add(g, 20, 14);
        gp.add(spray, 25, 14);
        gp.add(works, 30, 14);
        gp.add(c2, 35, 14);
        gp.add(v, 40, 14);
        gp.add(seven, 45, 14);
        gp.add(eight, 0, 19);
        gp.add(nine, 5, 19);
        gp.add(cpn, 10, 19);
        gp.add(airf, 15, 19);
        gp.add(ext, 20, 19);
        gp.add(fstend, 25, 19);
        gp.add(c1, 30, 19);
        gp.add(cncl, 35, 19);
        gp.add(spc, 40, 19);
        gp.add(four, 45, 19);
        gp.add(five, 0, 24);
        gp.add(six, 5, 24);
        gp.add(s, 10, 24);
        gp.add(gCpn, 15, 24);
        gp.add(dtl, 20, 24);
        gp.add(cheque, 25, 24);
        gp.add(item, 30, 24);
        gp.add(threeP, 35, 24);
        gp.add(one, 40, 24);
        gp.add(two, 45, 24);
        gp.add(three, 0, 29);
        gp.add(dlx, 5, 29);
        gp.add(cpnS, 10, 29);
        gp.add(sfs, 15, 29);
        gp.add(sbtl, 20, 29);
        gp.add(cp, 25, 29);
        gp.add(fourP, 30, 29);
        gp.add(oneDecPl, 35, 29);
        gp.add(twoDecPl, 40, 29);
        */
/*
        HBox hb = new HBox();

        // Set spacing (5 or 10 pixels)
        hb.setSpacing(10);

        hb.setAlignment(Pos.CENTER_RIGHT);

        gp.add(hb, 100, 100);



        primaryStage.setTitle("Santa Fe Car Wash");
        primaryStage.setMaximized(true);
        primaryStage.setScene(new Scene(gp, 100, 100));
        primaryStage.show();
    }
}
*/